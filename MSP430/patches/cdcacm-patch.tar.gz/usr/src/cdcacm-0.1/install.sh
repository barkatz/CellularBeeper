#!/bin/sh

#
# This patch fixes the cdc-acm driver so it works with TI Luanch pad (MSP430)
# My sources are from 23/5/2014
# You might want to obtain the newest cdc-acm driver yourself and apply the following patch yourself:
# (according to: http://e2e.ti.com/support/wireless_connectivity/f/156/t/53610.aspx?pi267162=3, )
# 
# in function 'acm_port_activate' look for (and comment out):
#  """
#		acm->ctrlout = ACM_CTRL_DTR | ACM_CTRL_RTS;
#  		if (acm_set_control(acm, acm->ctrlout) < 0 &&
# 		   (acm->ctrl_caps & USB_CDC_CAP_LINE))
#    		goto error_set_control;
#  """
#
# and in function acm_port_shutdown look for (comment out this line as well):
# """
# acm_set_control(acm, acm->ctrlout = 0);
# """
# 
# After you finished applying the patch, run ./install.sh
# It simply removes the cdc-acm fail driver and adds the new one.
# minicom should now work.
#

# install kernel headers and not the entire kernel source-code tree.
# apt-get install kernel-headers-`uname -r`

# install dkms
# apt-get install dkms

# prevent module from loading
# sudo blacklist cdcacm -> http://ubuntuforums.org/showthread.php?t=166624

# build cdcacm including the patch and install it
sudo rmmod cdc_acm # this is the original module, if you connect the msp430-rf2500 to the usb port
sudo rmmod cdcacm
sudo rmmod cdc-acm
sudo dkms uninstall -m cdcacm -v 0.1 
sudo dkms remove -m cdcacm -v 0.1 --all
sudo dkms add -m cdcacm -v 0.1 -k `uname -r`
sudo dkms build -m cdcacm -v 0.1 --verbose
sudo dkms install -m cdcacm -v 0.1
sudo modprobe cdc-acm

# display module info
dmesg | tail -1
modinfo /var/lib/dkms/cdcacm/0.1/`uname -r`/`uname -m`/module/cdc-acm.ko

